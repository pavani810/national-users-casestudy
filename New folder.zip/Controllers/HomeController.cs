﻿using casestudy001.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using System.Windows.Forms;
using System.Web.Security;
using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;

namespace casestudy001.Controllers
{
    public class HomeController : Controller
    {
        adv_casestudyEntities2 db = new adv_casestudyEntities2();
        //string Constring = "Data Source=INCHCMPC09176;Initial Catalog = casestudy; Integrated Security = True";

        // GET: Home
        public ActionResult Index()
        {
            //        //category fruit = new category();
            //        fruit.cat_name = Populatecategorys();
            return View();
        }

        [HttpGet]
        public ActionResult UserLogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UserLogin(login UserAuthenticate)
        {

            if (ModelState.IsValid)
            {
                var obj = db.logins.Where(a => a.login_id.Equals(UserAuthenticate.login_id) && a.login_password.Equals(UserAuthenticate.login_password)).FirstOrDefault();
                if (obj != null)
                {
                    Session["UserID"] = obj.login_id;
                    // Session["UserName"] = obj.Username.ToString();
                    //Session["Name"] = obj.tblPatientDetail.cFirstName + " " + obj.tblPatientDetail.cLastName;
                    //ViewData["name"] = obj.LoginName;
                    //TempData["login_id"] = UserAuthenticate.login_id;
                    return RedirectToAction("Index", "tasks");
                }
                else
                {
                    MessageBox.Show("Login Credentials are incorrect please try again");
                }
            }

            return View(UserAuthenticate);

        }


        // POST: /Account/LogOff
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            AuthenticationManager.SignOut(DefaultAuthenticationTypes.ApplicationCookie);
            return RedirectToAction("UserLogin", "Home");
        }

        private IAuthenticationManager AuthenticationManager
        {
            get
            {
                return HttpContext.GetOwinContext().Authentication;
            }
        }

    }
}

        //    [HttpPost]
        //    public ActionResult Index(category fruit)
        //    {
        //        db.categories  = Populatecategorys();
        //        var selectedItem = fruit.categories.Find(p => p.Value == fruit.cat_id.ToString());
        //        if (selectedItem != null)
        //        {
        //            selectedItem.Selected = true;
        //            ViewBag.Message = "Fruit: " + selectedItem.Text;
        //            //ViewBag.Message += "\\nQuantity: " + fruit.Quantity;
        //        }

        //        return View(fruit);
        //    }

         
//    {
//        public ActionResult Index()
//        {
//            return View();
//        }

//        public ActionResult About()
//        {
//            ViewBag.Message = "Your application description page.";

//            return View();
//        }

//        public ActionResult Contact()
//        {
//            ViewBag.Message = "Your contact page.";

//            return View();
//        }
//    }
